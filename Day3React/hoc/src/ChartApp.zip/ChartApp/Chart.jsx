import React from 'react'
import ChartApp from './ChartApp'
import chart from "./chart.module.css"
import { FaBeer, FaChevronDown } from 'react-icons/fa';
import {FiRefreshCw  } from 'react-icons/fi';
import {AiOutlineStock  } from 'react-icons/ai';

const Chart = () => {
  return (

    <>
    {/* sales detail div */}

    <div className={chart.salesDiv}>
      <h2>Sales detail</h2>
    
    </div>


    {/* total sales overvies div */}

   <div className={chart.totalSalesDiv}>

    <div>
      <h2>Total Sales Overview</h2>
      <p className={chart.aug7} >7 - 13 Aug, 2020</p>
    </div>
    <div>
      <p className={chart.refresh}> <FiRefreshCw/> Refresh Metrics</p>
      <p>Filter by| <b>This week</b><FaChevronDown/></p>
     

    </div>


   </div>

{/* chart div */}

<div className={chart.chartDiv}>
  <div className={chart.chartSection}>
   
   {/* upper div */}
   <div className={chart.upperDiv}>

    <div>
      
      <p>$74,729.00</p>
      <p><AiOutlineStock/>  +21% from last week </p>
    </div>
    <div>
      <p ><AiOutlineStock className={chart.stockImg}/>  Highest revenue since 2 weeks ago</p>
    </div>

   </div>

   {/* lower chart div */}

   <div>
    <ChartApp/>

   </div>


  </div>


  {/* side bar div */}
  <div className={chart.sideUpperDiv}>
    {/* upper div */}
    <div>
      <p>Total Profit</p>
      <p>$12,545.00</p>
      <p><AiOutlineStock/>  +23% from last week </p>
    </div>


    {/* lower div */}
    <div>
      <p>Total Products Sold</p>
      <p>329</p>
    </div>
  </div>
</div>
    
      
    
    </>
  )
}

export default Chart
